import numpy as np # math
import matplotlib.pyplot as plt # plotting
import matplotlib.image as mpimg # loading images
import pandas # handling csv data

fig = plt.figure(figsize=(8,7))

# loading a table with pandas
data_frame = pandas.read_csv("spread_data.csv")






# Run show, to make sure everything is displayed.
plt.show()